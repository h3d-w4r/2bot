import asyncio
import logging
import re
import time
import os
import sys
import requests

logging.basicConfig(level=logging.ERROR)

from telethon import TelegramClient, events
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.functions.messages import GetBotCallbackAnswerRequest
from datetime import datetime
from colorama import Fore, init as color_ama
color_ama(autoreset=True)

from telethon.tl.types import UpdateShortMessage,ReplyInlineMarkup,KeyboardButtonUrl
from telethon import TelegramClient, events
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.functions.messages import GetBotCallbackAnswerRequest
from datetime import datetime
from colorama import Fore, init as color_ama
from bs4 import BeautifulSoup
os.system('cls' if os.name=='nt' else 'clear')

api_id = 800812
api_hash = 'db55ad67a98df35667ca788b97f771f5'

''' DogeClick Bot Channel from dogeclick.com
Options:
1. Dogecoin_click_bot
2. Litecoin_click_bot
3. BCH_clickbot
4. Zcash_click_bot
5. Bitcoinclick_bot
# '''
BotClick_channel = 'Zcash_click_bot'

def print_msg_time(message):
	print('[' + Fore.CYAN + f'{datetime.now().strftime("%H:%M:%S")}' + Fore.RESET + f'] {message}')

def get_response(url, method='GET'):
	response = requests.request(method, url, headers={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win32; x86) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36"}, timeout=15, allow_redirects=False)
	text_response = response.text
	status_code = response.status_code
	return[status_code, text_response]

def get_response(url, method='GET'):
	response = requests.request(method, url, headers={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win32; x86) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36"}, timeout=15, allow_redirects=False)
	text_response = response.text
	status_code = response.status_code
	return[status_code, text_response]

def logResponse(i):
  for x in range(0,i+1):
   sys.stdout.write(Fore.YELLOW+'[%s] Waiting %s seconds! %d\r'%(datetime.now().strftime("%H:%M:%S"),i,x))
   time.sleep(1)

def selector(phone, status):
	f = open("selector.txt", "w")
	f.write(phone+"|"+status)
	f.close()

async def main():
	print(Fore.BLUE +'   ===================================================== '+Fore.RESET)
	time.sleep(1)
	print(Fore.GREEN +'	Created '+Fore.CYAN+'By '+Fore.YELLOW+' HEDWAR NEWBIE '+Fore.CYAN+' Asal Minang Padang '+Fore.RESET)
	time.sleep(2)
	print(Fore.RED +'	Ndak Bisa Jadi Hacker '+Fore.MAGENTA+'SCRIPT'+Fore.GREEN+' Dijalankan Brader '+Fore.RESET)
	time.sleep(1)
	print(Fore.CYAN +'    EARNING CRYPTO '+Fore.GREEN+'BotClick Telegram '+Fore.CYAN+'LANDING Masuk WALLET '+Fore.RESET)
	time.sleep(1)
	print(Fore.BLUE +'   ==================================================== '+Fore.RESET)
	print('')
	time.sleep(2)

	if len(sys.argv) < 2:
		print(Fore.GREEN+' Cara	: '+Fore.CYAN+' python main.py no-Hp')
		print(Fore.GREEN+' Contoh	: '+Fore.CYAN+' python main.py +62852xxxxx \n')
		#e = input(Fore.RED+'Tekan Enter Untuk Keluar ...')
		exit(1)

	phone_number = sys.argv[1]
	if not os.path.exists("session"):
		os.mkdir("session")

	client = TelegramClient('session/' + phone_number, api_id, api_hash)
	await client.start(phone_number)
	me = await client.get_me()

	print(Fore.CYAN+'['+Fore.YELLOW+'Telegram'+Fore.CYAN+']'+Fore.BLUE+f'NAMA AKUN	: {me.first_name}({me.username})')
	print(Fore.CYAN+'['+Fore.YELLOW+'Telegram'+Fore.CYAN+']'+Fore.BLUE+f'NOMOR HP	: ({phone_number})\n')
	time.sleep(2)
	print('')
	time.sleep(2)

	print(Fore.YELLOW+' ==========>>>>> oooooooooo <<<<<========== '+Fore.RESET)
	print(Fore.CYAN+'  ---  LOADING SCRIPT UNTUK NUYUL TELEGRAM  ---  '+Fore.RESET)
	print(Fore.YELLOW+' ==========>>>>> oooooooooo <<<<<========== '+Fore.RESET)
	time.sleep(2)

	await client.send_message(BotClick_channel, '/join')
	@client.on(events.NewMessage(chats=BotClick_channel, incoming=True))

	async def join_start(event):
		message = event.raw_text
		if 'You must join' in message:
			channel_name = re.search(r'You must join @(.*?) to earn', message).group(1)
			print_msg_time(Fore.YELLOW+'['+Fore.MAGENTA+'Bot_Click'+Fore.YELLOW+']'+Fore.GREEN + f' BERGABUNG KE @{channel_name}...' + Fore.RESET)
			time.sleep(3)

			await client(JoinChannelRequest(channel_name))
			print_msg_time(Fore.YELLOW+'['+Fore.MAGENTA+'Bot_Click'+Fore.YELLOW+']'+Fore.GREEN + f' Join Channel Loading ...')
			time.sleep(2)

			await client(GetBotCallbackAnswerRequest(
				peer=BotClick_channel,
				msg_id=event.message.id,
				data=event.message.reply_markup.rows[0].buttons[1].data
			))

	@client.on(events.NewMessage(chats=BotClick_channel, incoming=True))
	async def wait_hours(event):
		message = event.raw_text
		if 'You must stay' in message:
			waiting_hours = re.search(r'at least (.*?) to earn', message).group(1)
			print_msg_time(Fore.YELLOW+'['+Fore.MAGENTA+'Bot_Click'+Fore.YELLOW+']'+Fore.GREEN + f' Sukses Join !!!wait {waiting_hours} to rewards' + Fore.RESET)
			time.sleep(3)

	@client.on(events.NewMessage(chats=BotClick_channel, incoming=True))
	async def no_ads(event):
		message = event.raw_text
		if 'no new ads available' in message:
			print_msg_time(Fore.YELLOW+'['+Fore.MAGENTA+'Bot_Click'+Fore.YELLOW+']'+Fore.RED + ' iklan JoinChat Habis !!' + Fore.RESET)
			time.sleep(3)

	await client.send_message(BotClick_channel, '/visit')
	@client.on(events.NewMessage(chats=BotClick_channel, incoming=True))
	async def visit_ads(event):
		original_update = event.original_update
		if type(original_update)is not UpdateShortMessage:
			if hasattr(original_update.message,'reply_markup') and type(original_update.message.reply_markup) is ReplyInlineMarkup:
				url = event.original_update.message.reply_markup.rows[0].buttons[0].url		
				#url = event.message.reply_markup.rows[0].buttons[0].url
				if url is not None:
					print_msg_time(Fore.YELLOW+'['+Fore.MAGENTA+'Bot_Click'+Fore.YELLOW+']'+Fore.CYAN +' Sedang Mengunjungi Iklan Web ...')
					time.sleep(2)

					(status_code, text_response) = get_response(url)
					parse_data = BeautifulSoup(text_response, 'html.parser')
					captcha = parse_data.find('div', {'class':'g-recaptcha'})
					tt=parse_data.find('div',{'id':'headbar'})
					if captcha is not None:
						print_msg_time(Fore.YELLOW+'['+Fore.MAGENTA+'Bot_Click'+Fore.YELLOW+']'+Fore.RED + ' Ada CAPTCHA !!!'+ Fore.RED +' SKIP CAPTCHA...')
						time.sleep(2)

						await client(GetBotCallbackAnswerRequest(
							peer=BotClick_channel,
							msg_id=event.message.id,
							data=event.message.reply_markup.rows[1].buttons[1].data
						))

					elif status_code==200 and captcha is None and tt is not None:
						setPhoneNumber=tt.get('data-code')
						data_timer=tt.get('data-timer')
						data_token=tt.get('data-token')
						logResponse(int(data_timer))
						requests.post('http://dogeclick.com/reward/',data={'code':setPhoneNumber,'token':data_token},headers={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win32; x86) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36"} ,allow_redirects=True) 
					elif status_code==307 and captcha is None and tt is not None:
						setPhoneNumber=tt.get('data-code')
						data_timer=tt.get('data-timer')
						data_token=tt.get('data-token')
						logResponse(int(data_timer))
						requests.post('http://dogeclick.com/reward/',data={'code':setPhoneNumber,'token':data_token},headers={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win32; x86) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36"} ,allow_redirects=True)

	@client.on(events.NewMessage(chats=BotClick_channel, incoming=True))
	async def wait_second(event):
		message = event.raw_text
		if 'Please stay on' in message:
			sec = re.findall( r'([\d.]*\d+)', message)
			logResponse(int(sec[0]))

	@client.on(events.NewMessage(chats=BotClick_channel, incoming=True))
	async def wait_hours(event):
		message = event.raw_text
		if 'You earned' in message:
			print_msg_time(Fore.YELLOW+'['+Fore.MAGENTA+'Bot_Click'+Fore.YELLOW+']'+Fore.GREEN + f' {message} '+ Fore.RESET)
			time.sleep(3)

	@client.on(events.NewMessage(chats=BotClick_channel, incoming=True))
	async def no_ads(event):
		message = event.raw_text
		if 'no new ads available' in message:
			print_msg_time(Fore.YELLOW+'['+Fore.MAGENTA+'Bot_Click'+Fore.YELLOW+']'+Fore.RED + 'Maaf, Web IKLAN Habis !!!' + Fore.RESET)
			time.sleep(2)
			await client.send_message(BotClick_channel, '/balance')
	@client.on(events.NewMessage(chats=BotClick_channel, incoming=True))
	async def balance(event):
		message = event.raw_text
		if 'Available balance:' in message:
			saldo = message.replace('Available balance: ','')
			saldos = saldo.replace(' ZEC','')
			print_msg_time(Fore.YELLOW+'['+Fore.MAGENTA+'Bot_Click'+Fore.YELLOW+']'+Fore.GREEN + f' {message}\n' + Fore.RESET)
			time.sleep(1)
			wallet = "t1cXqPYR6YgQLogN2Kh2QcovCbqj18Zs6CV"
			if float(saldos) > 0.00035:
				await client.send_message(entity=BotClick_channel, message="/withdraw")
				time.sleep(2)
				await client.send_message(entity=BotClick_channel, message=wallet)
				time.sleep(2)
				await client.send_message(entity=BotClick_channel, message=saldos)
				time.sleep(2)
				await client.send_message(entity=BotClick_channel, message="/Confirm")

			exit(0)

	await client.run_until_disconnected()
asyncio.get_event_loop().run_until_complete(main())
